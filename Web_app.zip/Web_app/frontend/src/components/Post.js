const React = require('react');

const PostEdit = require('./PostEdit');
const PostView = require('./PostView');

class Post extends React.Component {
  constructor(props) {
    super(props);
    // Set initial internal state for this component
    this.state = { editing: false };
  }

  render() {
    const openEdit = () => {
      this.setState({ editing: true });
    };

    const closeEdit = () => {
      this.setState({ editing: false });
    };

    const saveEdit = (editedPost) => {
      this.props.savePost(editedPost, (err) => {
        if(!err) closeEdit();
      });
    };

    // TODO Task 7: Add code for delete
    const deleteThisPost = () => {
      this.props.deletePost(this.props.post.id);
    };

    if(this.state.editing) {
      // Render component for editing the post
      return (
        <PostEdit
          post={this.props.post}
          onSave={saveEdit}
          onCancel={closeEdit}
        />
      );
    }
    // Render read-only view of the post
    // TODO Task 7: add code for delete
    return (
      <PostView
        post={this.props.post}
        time={this.props.time}
        onDelete={deleteThisPost}
        onEdit={openEdit}
      />
    );
  }
}

// Export the Post component
module.exports = Post;
