const React = require('react');
const NoteEdit = require('./NoteEdit');


 // A button for new note
class NoteNew extends React.Component {
  constructor(props) {
    super(props);
    // Set initial internal state for this component
    this.state = { editing: false };
  }

  render() {
    const openEdit = () => {
      this.setState({ editing: true });
    };

    const closeEdit = () => {
      this.setState({ editing: false });
    };

    const createNote = (newNote) => {
      this.props.createNote(newNote, (err) => {
        if(!err) closeEdit();
      });
    };
       if(this.state.editing){
      // Render component for editing the Note
      return (
         <NoteEdit
          notebookIdentification={this.props.notebookIdentification}
          note={this.props.note}
          onSave={this.createNote}
          onCancel={this.closeEdit}
        />
      );
    }
    return (
      <button className="blog-load-more btn btn-primary btn-lg"
        onClick={ openEdit }
      >
        Write new Note
      </button>
    );
  }
}









module.exports = NoteNew;