const React = require('react');
const ReactRedux = require('react-redux');
const _ = require('lodash');

const createActionDispatchers = require('../helpers/createActionDispatchers');
const statisticsActionCreators = require('../reducers/statistics');


class Statistics extends React.Component {

  render() {
    const onRefreshButtonClick = () => {
    	this.props.loadStatistics();
    };

    return (
      <div>
        <h2>Statistics</h2>
        <table className="table ">
          <thead>
            <tr>
              <th scope="col">Statistic</th>
              <th scope="col">Value</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>notebookCount</td>
              <td>{this.props.statistics.visibleStatistics.notebookCount}</td>
            </tr>
            <tr>
              <td>noteCount</td>
              <td>{this.props.statistics.visibleStatistics.noteCount}</td>
            </tr>
            <tr>
              <td>oldestNotebook</td>
              <td>{this.props.statistics.visibleStatistics.oldestNotebook}</td>
            </tr>
            <tr>
              <td>recentlyUpdatedNote</td>
              <td>{this.props.statistics.visibleStatistics.recentlyUpdatedNote}</td>
            </tr>
          </tbody>
        </table>
        <button onClick={onRefreshButtonClick}>Refresh Stats</button>
      </div>
    );
  }
}

const StatisticsContainer = ReactRedux.connect(
  state => ({
    statistics: state.statistics,
  }),
  createActionDispatchers(statisticsActionCreators)
)(Statistics);
module.exports = StatisticsContainer;