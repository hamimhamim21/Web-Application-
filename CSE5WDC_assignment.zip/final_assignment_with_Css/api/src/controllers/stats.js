const express = require('express');
const _ = require('lodash');
const models = require('../models');

const router = express.Router();

// Index
//x->note count
//y->notebook count
//z->updated note
//a->oldest notebook
router.get('/', (req, res) => {
  models.Note.count().then(x=>(models.Notebook.count().then(y=>(models.Note.findOne( {order: [['updatedAt', 'DESC']] }).then(z=>(models.Notebook.findOne( {order: [['createdAt', 'ASC']] }).then(
    a=>res.json({
      notebookCount:y,
      noteCount:x ,
      oldestNotebook:a.title,
      recentlyUpdatedNote:z.title
    })
  )))))))
    .catch(err => res.status(500).json({ error: err.message }));
});



module.exports = router;

